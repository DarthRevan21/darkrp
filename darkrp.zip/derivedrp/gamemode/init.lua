hook.Run("DarkRPStartedLoading")

GM.Version = "1.0.0"
GM.Name = "DerivedRP"
GM.Author = "By Harry, FPtje Falco et al."

DeriveGamemode("darkrp")
DEFINE_BASECLASS("gamemode_darkrp")

GM.DarkRP = BaseClass
